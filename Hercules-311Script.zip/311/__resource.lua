-- Simple 311 Command (With Location & Blip) -- 
         -- Made By Hercules Designs --

client_scripts {
   'cl_311.lua'
}

server_scripts {
   'sv_311.lua'
}
-- Simple 311 Command (With Location & Blip) -- 
		-- Made By Drop --

displayLocation = true  -- By Changing this to 'false' it will make it so your location is not displayed in chat --
blips = true -- By Changing this to 'false' it will disable 311 call blips meaning your location will not be shown on the map --
disableChatCalls = false -- By Chaning this to 'false' it will make it so 311 call are not displayed in chat (Recommended to have Discord Webhook setup if disabling this) --
webhookurl = 'ADD 311 WEBHOOK HERE' -- Add your discord webhook url here, if you do not want this leave it blank (More info on FiveM post) --
ondutymode = false -- By chaning this to 'true' it will make it so only Emergency Services and people who have used the 'onduty' command can see 311 calls and blips --

-- Code --

local onduty = false

RegisterServerEvent('311')
AddEventHandler('311', function(location, msg, x, y, z, name, ped)
	local playername = GetPlayerName(source)
	local ped = GetPlayerPed(source)
	if displayLocation == false then
		if disableChatCalls == false then
			TriggerClientEvent('chatMessage', -1, '', {255,255,255}, '^*^3311 | Caller ID: ^r' .. playername .. '^*^3 | Report: ^r' .. msg)
			sendDiscord('311 Communications', '**311 | Caller ID: **' .. playername .. '** | Report: **' .. msg)  
		else
			sendDiscord('311 Communications', '**311 | Caller ID: **' .. playername .. '** | Report: **' .. msg)  
		end
	else
		if disableChatCalls == false then
			if ondutymode then
				TriggerClientEvent('311:sendtoteam', -1, playername, location, msg, x, y, z)
				TriggerClientEvent('chatMessage', source, '', {255,255,255}, '^*^3311 | Caller ID: ^r' .. playername .. '^*^3 | Location: ^r' .. location .. '^*^3 | Report: ^r' .. msg)
				TriggerClientEvent('chatMessage', source, '', {255,255,255}, '^1This call has been sent to Emergency Services.')
			else 
				TriggerClientEvent('chatMessage', -1, '', {255,255,255}, '^*^3311 | Caller ID: ^r' .. playername .. '^*^3 | Location: ^r' .. location .. '^*^3 | Report: ^r' .. msg)
			end
			sendDiscord('311 Communications', '**311 | Caller ID: **' .. playername .. '** | Location: **' .. location .. '** | Report: **' .. msg)
		else
			sendDiscord('311 Communications', '**311 | Caller ID: **' .. playername .. '** | Location: **' .. location .. '** | Report: **' .. msg)
		end
		if blips == true then
			if not ondutymode then
				TriggerClientEvent('311:setBlip', -1, name, x, y, z)
			end 
		end
	end
end)

RegisterServerEvent('311:sendmsg')
AddEventHandler('311:sendmsg', function(name, location, msg, x, y, z)
	TriggerClientEvent('chatMessage', source, '', {255,255,255}, '^*^3Dispatch: ^3311 | Caller ID: ^r' .. name .. '^*^3 | Location: ^r' .. location .. '^*^3 | Report: ^r' .. msg)
	if blips then
		TriggerClientEvent('311:setBlip', source, name, x, y, z)
	end
end)

function sendDiscord(name, message)
	local content = {
        {
        	["color"] = '16774912',
            ["title"] = "**".. name .."**",
            ["description"] = message,
            ["footer"] = {
                ["text"] = "This Call goes out to Roadside Assistance only",
            },
        }
    }
  	PerformHttpRequest(webhookurl, function(err, text, headers) end, 'POST', json.encode({username = name, embeds = content}), { ['Content-Type'] = 'application/json' })
end


	

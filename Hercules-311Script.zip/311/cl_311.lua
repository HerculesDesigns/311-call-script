-- Simple 311 Command (With Location & Blip) -- 
		-- Made By Drop --

displayTime = 300 -- Refreshes Blips every 5 Minutes by Default --  
ondutycommand = 'onduty' -- Change this if you already have a 'onduty' command already set --
passwordmode = false -- By Changing this to 'false' it will make it so you need a password to go on-duty --  { For the 'passwordmode' and 'password' to work you need to have 'ondutymode' set to 'true' } --
password = '123' -- Please change this to your desired password -- { For the 'passwordmode' and 'password' to work you need to have 'ondutymode' set to 'true' } --

-- Code --

blip = nil
blips = {}

local onduty = false

RegisterCommand(ondutycommand, function(source, args)
    if passwordmode then 
        if args[1] == password then
            if not onduty then 
                onduty = true
                TriggerEvent('chatMessage', '', {255,255,255}, '^3You are now ^*On-Duty^r^3 and you are able to recieve 311 calls.')
            else
                onduty = false
                TriggerEvent('chatMessage',  '', {255,255,255}, '^1You are now ^*Off-Duty^r^1 and you will no longer be able to recieve 311 calls.')
            end
        else
            TriggerEvent('chatMessage', '', {255,255,255}, '^1Incorrect Password')
        end
    else
        if not onduty then 
            onduty = true
            TriggerEvent('chatMessage', '', {255,255,255}, '^3You are now ^*On-Duty^r^3 and you are able to recieve 311 calls.')
        else
            onduty = false
            TriggerEvent('chatMessage', '', {255,255,255}, '^1You are now ^*Off-Duty^r^1 and you will no longer be able to recieve 311 calls.')
        end
    end 
end)


Citizen.CreateThread(function()
    TriggerEvent('chat:addSuggestion', '/311', 'Submits a 311 call to Roadside Assistance!', {
    { name="Report", help="Enter the incident/report here!" }
})
end)

RegisterNetEvent('311:setBlip')
AddEventHandler('311:setBlip', function(name, x, y, z)
    blip = AddBlipForCoord(x, y, z)
    SetBlipSprite(blip, 380)
    SetBlipScale(blip, 1.5)
    SetBlipColour(blip, 5)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString('311 Call - ' .. name)
    EndTextCommandSetBlipName(blip)
    table.insert(blips, blip)
    Wait(displayTime * 1000)
    for i, blip in pairs(blips) do 
        RemoveBlip(blip)
    end
end)

RegisterNetEvent('311:sendtoteam')
AddEventHandler('311:sendtoteam', function(name, location, msg, x, y, z)
    if onduty then 
        TriggerServerEvent('311:sendmsg', name, location, msg, x, y, z)
    end
end)

-- Command -- 

RegisterCommand('311', function(source, args)
    local name = GetPlayerName(PlayerId())
    local ped = GetPlayerPed(PlayerId())
    local x, y, z = table.unpack(GetEntityCoords(ped, true))
    local street = GetStreetNameAtCoord(x, y, z)
    local location = GetStreetNameFromHashKey(street)
    local msg = table.concat(args, ' ')
    if args[1] == nil then
        TriggerEvent('chatMessage', '^3311', {255,255,255}, ' ^7Please enter for ^3Roadside Assistance.')
    else
        TriggerServerEvent('311', location, msg, x, y, z, name)
    end
end)

